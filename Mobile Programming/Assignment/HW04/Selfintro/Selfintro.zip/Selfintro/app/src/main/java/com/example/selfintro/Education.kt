package com.example.selfintro

data class Education(
    val educationDegree: String,
    val major: String,
    val duration: String,
    val imageResource: Int
)