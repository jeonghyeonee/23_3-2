package com.example.selfintro

data class Activity(
    val orgTitle: String,
    val subTitle: String,
    val duration: String,
    val imageResource: Int
)
