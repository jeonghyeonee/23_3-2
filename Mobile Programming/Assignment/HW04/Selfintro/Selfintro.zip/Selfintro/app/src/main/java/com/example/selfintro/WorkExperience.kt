package com.example.selfintro

data class WorkExperience(
    val jobTitle: String,
    val companyName: String,
    val duration: String,
    val imageResource: Int
)