package com.example.selfintro

data class Skill(
    val name: String
)

